"""
Performance tests for Fire-EMS Tools.
"""