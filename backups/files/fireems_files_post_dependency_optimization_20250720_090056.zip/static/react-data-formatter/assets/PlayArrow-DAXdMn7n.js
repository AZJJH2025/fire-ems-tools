import{j as o}from"./index-C9c-eot0.js";import{c as r}from"./Typography-CZA_M_LP.js";const a=r(o.jsx("path",{d:"M8 5v14l11-7z"}));export{a as P};
