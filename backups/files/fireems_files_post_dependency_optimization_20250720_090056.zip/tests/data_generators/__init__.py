"""
Data generators for creating test data for different test scenarios.
"""