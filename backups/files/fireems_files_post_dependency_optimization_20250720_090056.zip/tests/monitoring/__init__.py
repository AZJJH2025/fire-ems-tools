"""
Monitoring and alerting for test results.

This package contains utilities for monitoring test results and sending alerts.
"""