"""
API tests for Fire-EMS Tools.
"""