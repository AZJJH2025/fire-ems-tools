"""
Testing package for Fire-EMS Tools application.
"""