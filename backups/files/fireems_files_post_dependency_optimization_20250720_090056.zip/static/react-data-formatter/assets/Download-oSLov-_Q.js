import{j as o}from"./index-D64hivy_.js";import{c as t}from"./Typography-CLsfDxFh.js";const a=t(o.jsx("path",{d:"M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z"}));export{a as D};
