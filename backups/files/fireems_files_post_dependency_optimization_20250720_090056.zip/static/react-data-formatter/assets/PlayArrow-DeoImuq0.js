import{j as o}from"./index-D64hivy_.js";import{c as r}from"./Typography-CLsfDxFh.js";const a=r(o.jsx("path",{d:"M8 5v14l11-7z"}));export{a as P};
