"""
Contract testing for Fire-EMS Tools.

This package contains contract tests to verify that services
integrate correctly.
"""