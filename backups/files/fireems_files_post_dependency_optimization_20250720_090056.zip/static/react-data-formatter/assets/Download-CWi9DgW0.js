import{j as o}from"./index-DCcSIHV8.js";import{c as t}from"./Typography-C3C1nKUN.js";const a=t(o.jsx("path",{d:"M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z"}));export{a as D};
