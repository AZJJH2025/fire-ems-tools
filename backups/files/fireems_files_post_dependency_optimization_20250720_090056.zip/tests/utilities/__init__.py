"""
Utilities module for test data management and test helpers.
"""