"""
Integration tests for Fire-EMS Tools.
"""